<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\BahanController;
use App\Http\Controllers\ResepController;
use App\Http\Controllers\ProduksiController;
use App\Http\Controllers\LaporanController;

// =================== LOGIN ===================

Route::get('/', function () {
    return view('login');
});

Route::post('/login', function (Request $request) {

    if (
        ($request->nama == 'neyaa' && $request->password == '123') ||
        ($request->nama == 'gitaa' && $request->password == '123')
    ) {
        session(['user' => $request->nama]);

        return redirect('/home');
    }

    return back()->with('error', 'Nama atau password salah');
});

// =================== HALAMAN YANG HARUS LOGIN ===================

Route::middleware('cekLogin')->group(function () {

    Route::get('/home', function () {
        return view('home');
    });

    Route::get('/dashboard', function () {
        return app(DashboardController::class)->index();
    });

    // =================== DATA BAHAN ===================

    Route::get('/bahan', function () {
        return app(BahanController::class)->index();
    });

    Route::post('/bahan', function (Request $request) {
        return app(BahanController::class)->store($request);
    });

    Route::get('/bahan/hapus/{id}', function ($id) {
        return app(BahanController::class)->destroy($id);
    });

    // =================== RESEP ===================

    Route::get('/resep', function () {
        return app(ResepController::class)->index();
    });

    Route::post('/resep', function (Request $request) {
        return app(ResepController::class)->store($request);
    });

    Route::get('/resep/hapus/{id}', function ($id) {
        return app(ResepController::class)->destroy($id);
    });

    // =================== PRODUKSI ===================

    Route::get('/produksi', function () {
        return app(ProduksiController::class)->index();
    });

    Route::post('/produksi', function (Request $request) {
        return app(ProduksiController::class)->store($request);
    });

    Route::get('/produksi/hapus/{id}', function ($id) {
        return app(ProduksiController::class)->destroy($id);
    });

    // =================== LAPORAN ===================

    Route::get('/laporan', function (Request $request) {
        return app(LaporanController::class)->index($request);
    });

    // =================== LOGOUT ===================

    Route::get('/logout', function () {
        session()->flush();
        return redirect('/');
    });

});