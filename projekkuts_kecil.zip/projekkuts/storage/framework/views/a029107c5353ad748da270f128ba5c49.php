<!DOCTYPE html>
<html>
<head>
    <title>Aurévia Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      body{
    margin:0;
    background:#f8f9fa;
    display:flex;
}

        .sidebar{
    width:250px;
    min-height:100vh;
    background:#400100;
    color:white;
    padding:20px;
    position:fixed;
    left:0;
    top:0;
    bottom:0;
}

        .sidebar a {
            display: block;
            color: white;
            padding: 10px;
            text-decoration: none;
            border-radius: 6px;
        }

        .sidebar a:hover {
            background: #fff0db;
            color: black;
        }

       .content{
    margin-left:250px;
    width:calc(100% - 250px);
    min-height:100vh;
    padding:20px;
}

        .card {
            border-radius: 12px;
        }
    </style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="text-center mb-3">
        <img src="sticker.png" width="100">
        <h5 class="mt-2">Aurévia</h5>

        <a href="/logout" style="color:#ffb3b3;">Logout</a>
    </div>

    <a href="/dashboard">Dashboard</a>
    <a href="/bahan">Data Bahan</a>
    <a href="/produksi">Produksi</a>
    <a href="/resep">Resep</a>
    <a href="/laporan">Laporan</a>
</div>

<!-- CONTENT -->
<div class="content">
<?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html><?php /**PATH D:\projekkuts\resources\views/layouts/app.blade.php ENDPATH**/ ?>