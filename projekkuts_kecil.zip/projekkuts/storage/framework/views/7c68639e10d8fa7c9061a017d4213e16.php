<!DOCTYPE html>
<html>
<head>
    <title>Login - Aurévia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #Fff0db;
            font-family: 'Poppins', sans-serif;
        }

        .card {
            border-radius: 12px;
        }

        .btn-custom {
            background: #400100;
            color: white;
        }

        .btn-custom:hover {
            background: #600200;
            color: white;
        }
    </style>
</head>
<body>

<div class="d-flex justify-content-center align-items-center vh-100">

    <form method="POST" action="/login" class="card p-4 shadow" style="width:320px;">
        <?php echo csrf_field(); ?>

        <div class="text-center mb-3">
            <img src="/sticker.png" width="80">
            <h4 class="mt-2">Aurévia Admin</h4>
        </div>

        <!-- ERROR -->
        <?php if(session('error')): ?>
            <div class="alert alert-danger text-center">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <!-- INPUT -->
        <input 
            type="text" 
            name="nama" 
            class="form-control mb-2" 
            placeholder="Nama"
            required
        >

        <input 
            type="password" 
            name="password" 
            class="form-control mb-3" 
            placeholder="Password"
            required
        >

        <!-- BUTTON -->
        <button type="submit" class="btn btn-custom w-100">
            Login
        </button>

        <!-- INFO -->
        <p class="text-center mt-3" style="font-size:12px; color:gray;">
        </p>

    </form>

</div>

</body>
</html><?php /**PATH D:\projekkuts\resources\views/login.blade.php ENDPATH**/ ?>