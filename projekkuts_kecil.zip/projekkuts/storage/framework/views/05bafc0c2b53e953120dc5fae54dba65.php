

<?php $__env->startSection('content'); ?>
<h2 class="mb-4">Menu Utama</h2>

<div class="row">

    <div class="col-md-4 mb-3">
        <a href="/dashboard" class="text-decoration-none">
            <div class="card p-4 text-center shadow-sm">
                <h4>📊 Dashboard</h4>
            </div>
        </a>
    </div>

    <div class="col-md-4 mb-3">
        <a href="/bahan" class="text-decoration-none">
            <div class="card p-4 text-center shadow-sm">
                <h4>📦 Data Bahan</h4>
            </div>
        </a>
    </div>

    <div class="col-md-4 mb-3">
        <a href="/resep" class="text-decoration-none">
            <div class="card p-4 text-center shadow-sm">
                <h4>📖 Resep</h4>
            </div>
        </a>
    </div>

    <div class="col-md-6 mb-3">
        <a href="/produksi" class="text-decoration-none">
            <div class="card p-4 text-center shadow-sm">
                <h4>🏭 Produksi</h4>
            </div>
        </a>
    </div>

    <div class="col-md-6 mb-3">
        <a href="/laporan" class="text-decoration-none">
            <div class="card p-4 text-center shadow-sm">
                <h4>📈 Laporan</h4>
            </div>
        </a>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projekkuts\resources\views/home.blade.php ENDPATH**/ ?>