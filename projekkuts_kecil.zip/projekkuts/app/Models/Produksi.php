<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Produksi extends Model
{
    protected $table = 'produksi';

    protected $primaryKey = 'id_produksi';

    public $timestamps = false;

    protected $fillable = [
        'nama_produk',
        'tanggal_produksi',
        'jumlah_loyang',
        'total_slice'
    ];
}