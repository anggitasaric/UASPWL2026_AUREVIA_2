<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Resep extends Model
{
    protected $table = 'resep';

    protected $primaryKey = 'id_resep';

    public $timestamps = false;

    protected $fillable = [
        'nama_produk',
        'id_bahan',
        'jumlah_bahan'
    ];

    public function bahan()
    {
        return $this->belongsTo(Bahan::class, 'id_bahan', 'id_bahan');
    }
}