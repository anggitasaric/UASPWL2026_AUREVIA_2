<?php

namespace App\Http\Controllers;

use App\Models\Bahan;
use App\Models\Resep;
use App\Models\Produksi;

class DashboardController extends Controller
{
    public function index()
    {
        $totalBahan = Bahan::count();

        $totalResep = Resep::distinct('nama_produk')->count('nama_produk');

        $totalProduksi = Produksi::count();

        $totalSlice = Produksi::sum('total_slice');

        $aktivitas = Produksi::latest('tanggal_produksi')
                        ->take(5)
                        ->get();

        return view('dashboard', compact(
            'totalBahan',
            'totalResep',
            'totalProduksi',
            'totalSlice',
            'aktivitas'
        ));
    }
}