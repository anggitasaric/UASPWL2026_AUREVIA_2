<?php

namespace App\Http\Controllers;

use App\Models\Produksi;
use Illuminate\Http\Request;

class LaporanController extends Controller
{
    public function index(Request $request)
    {
        $query = Produksi::query();

        if ($request->tanggal) {
            $query->whereDate('tanggal_produksi', $request->tanggal);
        }

        $laporan = $query->orderBy('tanggal_produksi', 'desc')->get();

        return view('laporan.index', compact('laporan'));
    }
}