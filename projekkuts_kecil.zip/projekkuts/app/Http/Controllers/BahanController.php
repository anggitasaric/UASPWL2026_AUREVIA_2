<?php

namespace App\Http\Controllers;

use App\Models\Bahan;
use Illuminate\Http\Request;

class BahanController extends Controller
{
    // Menampilkan semua data bahan
    public function index()
    {
        $bahan = Bahan::all();
        return view('bahan.index', compact('bahan'));
    }

    // Menyimpan data bahan
    public function store(Request $request)
    {
        $request->validate([
            'nama_bahan' => 'required',
            'stok' => 'required|integer',
            'satuan' => 'required',
        ]);

        Bahan::create([
            'nama_bahan' => $request->nama_bahan,
            'stok' => $request->stok,
            'satuan' => $request->satuan,
        ]);

        return redirect('/bahan')->with('success', 'Data bahan berhasil ditambahkan.');
    }

    // Menghapus data
    public function destroy($id)
    {
        $bahan = Bahan::findOrFail($id);
        $bahan->delete();

        return redirect('/bahan')->with('success', 'Data bahan berhasil dihapus.');
    }
}