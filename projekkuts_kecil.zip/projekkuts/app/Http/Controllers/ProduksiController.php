<?php

namespace App\Http\Controllers;

use App\Models\Produksi;
use Illuminate\Http\Request;

class ProduksiController extends Controller
{
    public function index()
    {
        $produksi = Produksi::all();

        return view('produksi.index', compact('produksi'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_produk' => 'required',
            'tanggal_produksi' => 'required',
            'jumlah_loyang' => 'required|numeric',
            'total_slice' => 'required|numeric'
        ]);

        Produksi::create([
            'nama_produk' => $request->nama_produk,
            'tanggal_produksi' => $request->tanggal_produksi,
            'jumlah_loyang' => $request->jumlah_loyang,
            'total_slice' => $request->total_slice,
        ]);

        return redirect('/produksi')->with('success', 'Data produksi berhasil disimpan.');
    }

    public function destroy($id)
    {
        Produksi::destroy($id);

        return redirect('/produksi');
    }
}