<?php

namespace App\Http\Controllers;

use App\Models\Resep;
use App\Models\Bahan;
use Illuminate\Http\Request;

class ResepController extends Controller
{
    public function index()
    {
        $bahan = Bahan::all();
        $resep = Resep::with('bahan')->get();

        return view('resep.index', compact('bahan', 'resep'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_produk' => 'required',
            'id_bahan' => 'required|array',
            'jumlah_bahan' => 'required|array'
        ]);

        foreach ($request->id_bahan as $index => $idBahan) {

            Resep::create([
                'nama_produk' => $request->nama_produk,
                'id_bahan' => $idBahan,
                'jumlah_bahan' => $request->jumlah_bahan[$index],
            ]);

        }

        return redirect('/resep')->with('success', 'Resep berhasil disimpan.');
    }

    public function destroy($id)
    {
        Resep::destroy($id);

        return redirect('/resep');
    }
}