@extends('layouts.app')

@section('content')

<h4 class="mb-4">Halo, {{ session('user') }} 👋</h4>

<h2 class="mb-4">Dashboard</h2>

<div class="row">

    <div class="col-md-3 mb-3">
        <div class="card text-center p-4 shadow-sm">
            <h6>Total Produksi</h6>
            <h2 style="color:#400100">{{ $totalProduksi }}</h2>
        </div>
    </div>

    <div class="col-md-3 mb-3">
        <div class="card text-center p-4 shadow-sm">
            <h6>Total Slice</h6>
            <h2 style="color:#400100">{{ $totalSlice }}</h2>
        </div>
    </div>

    <div class="col-md-3 mb-3">
        <div class="card text-center p-4 shadow-sm">
            <h6>Total Resep</h6>
            <h2 style="color:#400100">{{ $totalResep }}</h2>
        </div>
    </div>

    <div class="col-md-3 mb-3">
        <div class="card text-center p-4 shadow-sm">
            <h6>Total Bahan</h6>
            <h2 style="color:#400100">{{ $totalBahan }}</h2>
        </div>
    </div>

</div>

<div class="card p-4 mt-3">

    <h4>Aktivitas Terbaru</h4>

    <table class="table table-bordered mt-3">

        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Produk</th>
                <th>Loyang</th>
                <th>Slice</th>
            </tr>
        </thead>

        <tbody>

        @forelse($aktivitas as $item)

            <tr>
                <td>{{ $item->tanggal_produksi }}</td>
                <td>{{ $item->nama_produk }}</td>
                <td>{{ $item->jumlah_loyang }}</td>
                <td>{{ $item->total_slice }}</td>
            </tr>

        @empty

            <tr>
                <td colspan="4" class="text-center">
                    Belum ada aktivitas produksi.
                </td>
            </tr>

        @endforelse

        </tbody>

    </table>

</div>

@endsection