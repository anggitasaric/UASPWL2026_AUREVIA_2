@extends('layouts.app')

@section('content')

<h2>Laporan Produksi</h2>

<div class="card p-4 mb-4">

<form method="GET" action="/laporan">

<div class="row">

    <div class="col-md-4">
        <label>Tanggal Produksi</label>
        <input type="date"
               name="tanggal"
               class="form-control"
               value="{{ request('tanggal') }}">
    </div>

    <div class="col-md-2 d-flex align-items-end">
        <button class="btn btn-success w-100">
            Tampilkan
        </button>
    </div>

</div>

</form>

</div>

<div class="card p-4">

<h4>Data Produksi</h4>

<table class="table table-bordered mt-3">

<thead>

<tr>
    <th>No</th>
    <th>Tanggal</th>
    <th>Produk</th>
    <th>Jumlah Loyang</th>
    <th>Total Slice</th>
</tr>

</thead>

<tbody>

@php
$no = 1;
$totalLoyang = 0;
$totalSlice = 0;
@endphp

@forelse($laporan as $item)

<tr>

<td>{{ $no++ }}</td>
<td>{{ $item->tanggal_produksi }}</td>
<td>{{ $item->nama_produk }}</td>
<td>{{ $item->jumlah_loyang }}</td>
<td>{{ $item->total_slice }}</td>

</tr>

@php
$totalLoyang += $item->jumlah_loyang;
$totalSlice += $item->total_slice;
@endphp

@empty

<tr>
    <td colspan="5" class="text-center">
        Belum ada data produksi.
    </td>
</tr>

@endforelse

</tbody>

<tfoot>

<tr class="table-secondary">
    <th colspan="3">TOTAL</th>
    <th>{{ $totalLoyang }}</th>
    <th>{{ $totalSlice }}</th>
</tr>

</tfoot>

</table>

</div>

@endsection