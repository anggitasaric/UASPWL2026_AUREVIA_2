@extends('layouts.app')

@section('content')

<h2>Data Resep</h2>

@if(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif

<div class="card p-4">

<form action="/resep" method="POST">
@csrf

<div class="mb-3">
    <label>Nama Produk</label>
    <input type="text"
           name="nama_produk"
           class="form-control"
           placeholder="Contoh: Mille Crepe Coklat"
           required>
</div>

<table class="table table-bordered" id="tabelResep">

<thead>
<tr>
    <th width="45%">Bahan</th>
    <th width="35%">Jumlah</th>
    <th width="20%">Aksi</th>
</tr>
</thead>

<tbody>

<tr>

<td>

<select name="id_bahan[]" class="form-control" required>

@foreach($bahan as $item)

<option value="{{ $item->id_bahan }}">
    {{ $item->nama_bahan }}
</option>

@endforeach

</select>

</td>

<td>

<input type="text"
       name="jumlah_bahan[]"
       class="form-control"
       placeholder="Contoh: 200 gr"
       required>

</td>

<td>

<button type="button"
        class="btn btn-danger"
        onclick="hapusBaris(this)">
Hapus
</button>

</td>

</tr>

</tbody>

</table>

<button type="button"
        class="btn btn-primary"
        onclick="tambahBaris()">
+ Tambah Baris
</button>

<button type="submit"
        class="btn btn-success">
Simpan Resep
</button>

</form>

</div>

<hr>

<h4>Daftar Resep</h4>

<table class="table table-bordered">

<thead>

<tr>
    <th>Produk</th>
    <th>Nama Bahan</th>
    <th>Jumlah</th>
</tr>

</thead>

<tbody>

@foreach($resep as $item)

<tr>

<td>{{ $item->nama_produk }}</td>
<td>{{ $item->bahan->nama_bahan }}</td>
<td>{{ $item->jumlah_bahan }}</td>

</tr>

@endforeach

</tbody>

</table>

<script>

function tambahBaris(){

let tbody=document.querySelector("#tabelResep tbody");

let baris=tbody.rows[0].cloneNode(true);

baris.querySelector("input").value="";

tbody.appendChild(baris);

}

function hapusBaris(btn){

let tbody=document.querySelector("#tabelResep tbody");

if(tbody.rows.length>1){

btn.parentNode.parentNode.remove();

}

}

</script>

@endsection