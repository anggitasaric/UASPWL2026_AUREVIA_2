@extends('layouts.app')

@section('content')

<h2>Data Bahan</h2>

@if(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif

<button class="btn btn-primary mb-3" onclick="toggleForm()">
    + Tambah Bahan
</button>

<!-- FORM -->
<div id="formBahan" class="card p-3 mb-3" style="display:none;">

<form action="/bahan" method="POST">
    @csrf

    <div class="mb-2">
        <label>Nama Bahan</label>
        <input
            type="text"
            name="nama_bahan"
            class="form-control"
            required>
    </div>

    <div class="mb-2">
        <label>Stok</label>
        <input
            type="number"
            name="stok"
            class="form-control"
            required>
    </div>

    <div class="mb-3">
        <label>Satuan</label>
        <input
            type="text"
            name="satuan"
            class="form-control"
            required>
    </div>

    <button class="btn btn-success">
        Simpan
    </button>

</form>

</div>

<table class="table table-bordered bg-white">

<thead>

<tr>
    <th>Nama Bahan</th>
    <th>Stok</th>
    <th>Satuan</th>
    <th width="120">Aksi</th>
</tr>

</thead>

<tbody>

@forelse($bahan as $item)

<tr>

<td>{{ $item->nama_bahan }}</td>

<td>{{ $item->stok }}</td>

<td>{{ $item->satuan }}</td>

<td>

<a href="/bahan/hapus/{{ $item->id_bahan }}"
class="btn btn-danger btn-sm"
onclick="return confirm('Yakin ingin menghapus?')">
Hapus
</a>

</td>

</tr>

@empty

<tr>
<td colspan="4" class="text-center">
Belum ada data bahan.
</td>
</tr>

@endforelse

</tbody>

</table>

<script>

function toggleForm(){

let form=document.getElementById("formBahan");

if(form.style.display==="none"){
    form.style.display="block";
}else{
    form.style.display="none";
}

}

</script>

@endsection