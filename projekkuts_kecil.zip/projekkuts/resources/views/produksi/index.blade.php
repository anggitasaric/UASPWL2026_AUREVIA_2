@extends('layouts.app')

@section('content')

<h2>Produksi</h2>

@if(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif

<div class="card p-4 mb-4">

<form action="/produksi" method="POST">

@csrf

<div class="mb-3">
    <label>Nama Produk</label>
    <select name="nama_produk" id="resep" class="form-control">
        <option value="Mille Crepe Coklat" data-slice="10">Mille Crepe Coklat (10 slice)</option>
        <option value="Mille Crepe Matcha" data-slice="8">Mille Crepe Matcha (8 slice)</option>
    </select>
</div>

<div class="mb-3">
    <label>Tanggal Produksi</label>
    <input type="date"
           name="tanggal_produksi"
           class="form-control"
           value="{{ date('Y-m-d') }}">
</div>

<div class="mb-3">
    <label>Jumlah Loyang</label>
    <input type="number"
           name="jumlah_loyang"
           id="loyang"
           class="form-control"
           placeholder="Masukkan jumlah loyang">
</div>

<div class="mb-3">
    <label>Total Slice</label>
    <input type="number"
           name="total_slice"
           id="hasil"
           class="form-control"
           readonly>
</div>

<button class="btn btn-success">
    Simpan Produksi
</button>

</form>

</div>

<h4>Riwayat Produksi</h4>

<table class="table table-bordered">

<thead>

<tr>
    <th>Produk</th>
    <th>Tanggal</th>
    <th>Loyang</th>
    <th>Total Slice</th>
    <th>Aksi</th>
</tr>

</thead>

<tbody>

@foreach($produksi as $item)

<tr>

<td>{{ $item->nama_produk }}</td>
<td>{{ $item->tanggal_produksi }}</td>
<td>{{ $item->jumlah_loyang }}</td>
<td>{{ $item->total_slice }}</td>

<td>
    <a href="/produksi/hapus/{{ $item->id_produksi }}"
       class="btn btn-danger btn-sm"
       onclick="return confirm('Hapus data?')">
        Hapus
    </a>
</td>

</tr>

@endforeach

</tbody>

</table>

<script>

function hitung(){

let select=document.getElementById("resep");

let slice=select.options[select.selectedIndex].dataset.slice;

let loyang=document.getElementById("loyang").value;

document.getElementById("hasil").value=slice*loyang;

}

document.getElementById("resep").addEventListener("change",hitung);
document.getElementById("loyang").addEventListener("input",hitung);

</script>

@endsection